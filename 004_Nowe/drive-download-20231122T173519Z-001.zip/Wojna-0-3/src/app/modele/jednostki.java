package app.modele;

public enum jednostki {

}
